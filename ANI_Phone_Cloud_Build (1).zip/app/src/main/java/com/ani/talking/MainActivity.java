package com.ani.talking;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi","IN"));
        });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 9);
    }

    private void listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition उपलब्ध नहीं है", Toast.LENGTH_SHORT).show();
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);

        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p){ js("setStatus('Listening…')"); }
            public void onBeginningOfSpeech(){ }
            public void onRmsChanged(float r){ }
            public void onBufferReceived(byte[] b){ }
            public void onEndOfSpeech(){ js("setStatus('Thinking…')"); }
            public void onError(int e){ js("setStatus('Tap mic and try again')"); }
            public void onResults(Bundle r){
                ArrayList<String> x=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text=(x!=null && !x.isEmpty())?x.get(0):"";
                js("userSaid("+quote(text)+")");
                // Demo response. Replace with your secure backend call for real AI.
                String reply = demoReply(text);
                js("aniReply("+quote(reply)+")");
                speak(reply);
            }
            public void onPartialResults(Bundle r){}
            public void onEvent(int a, Bundle b){}
        });
        recognizer.startListening(i);
    }

    private String demoReply(String q) {
        String x=q.toLowerCase(Locale.ROOT);
        if (x.contains("hello") || x.contains("हेलो") || x.contains("हाय")) return "हाय! मैं ANI हूँ 😊 आज कैसे हो?";
        if (x.contains("कैसे हो") || x.contains("how are you")) return "मैं बहुत अच्छी हूँ। तुम बताओ, आज क्या कर रहे हो?";
        if (x.contains("नाम")) return "मेरा नाम ANI है। मैं तुम्हारी AI cartoon friend हूँ।";
        return "मैंने तुम्हारी बात सुनी 😊 अभी मैं demo mode में हूँ। असली AI जवाब के लिए backend जोड़ना होगा।";
    }

    private void speak(String text) {
        if (tts == null) return;
        runOnUiThread(() -> {
            js("setStatus('Speaking…'); startTalking()");
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ANI_REPLY");
        });
    }

    private void js(String code) { runOnUiThread(() -> web.evaluateJavascript("javascript:"+code, null)); }
    private String quote(String s) { return "'" + s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ") + "'"; }

    public class Bridge {
        @android.webkit.JavascriptInterface public void startListening() { runOnUiThread(() -> listen()); }
        @android.webkit.JavascriptInterface public void stopTalking() { runOnUiThread(() -> { if(tts!=null) tts.stop(); js("stopTalking()"); }); }
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
